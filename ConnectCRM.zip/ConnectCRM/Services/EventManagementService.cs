﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk.Query;

using EventsManagement.Database;
using EventsManagement.Utils;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using System.ServiceModel;

namespace EventsManagement.Services
{
    public class Registrant
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
    }
    public class PurchaseInfo
    {
        [JsonProperty("amount")]
        public string Amount { get; set; }
        //public List<Registrant> attendees { get; set; }
        public Registrant[] attendees { get; set; }
        public string currencyName { get; set; }
        public string currencySymbol { get; set; }
        public string eventName { get; set; }
        public string isoCurrencyCode { get; set; }
    }
    public class OrganizationDetails
    {
        [JsonProperty("dcuk_name")]
        public string Name { get; set; }
        [JsonProperty("dcuk_address1")]
        public string Address1 { get; set; }
        [JsonProperty("dcuk_address2")]
        public string Address2 { get; set; }
        [JsonProperty("dcuk_city")]
        public string City { get; set; }
        [JsonProperty("dcuk_zipcode")]
        public string Zipcode { get; set; }
        [JsonProperty("dcuk_state")]
        public string State { get; set; }
        [JsonProperty("dcuk_country")]
        public string Country { get; set; }
        [JsonProperty("dcuk_annualturnover")]
        public string AnnualTurnover { get; set; }
        [JsonProperty("dcuk_readableeventid")]
        public string ReadableEventId { get; set; }
        [JsonProperty("dcuk_purchaseid")]
        public string PurchaseId { get; set; }
    }

    public class EventManagementService
    {
        private const string PURCHASEDETAILEDINFO = "/api/data/v9.0/msevtmgt_ListDetailedPurchaseInfo ";
        static string organizationUrl = Environment.GetEnvironmentVariable("DataverseOrgURL", EnvironmentVariableTarget.Process);
        private async Task<List<string>> getEventTags(string eventId, ILogger log)
        {
            try
            {
                string fetchTagsXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                                        <fetch>
                                            <entity name=""dcuk_msevtmgt_event_dcuk_eventtags"">
                                                <attribute name=""dcuk_eventtagsid"" />
                                                <link-entity name=""dcuk_eventtags"" from=""dcuk_eventtagsid"" to=""dcuk_eventtagsid"" link-type=""inner"" >
                                                    <attribute name = ""dcuk_name""  alias=""eventTag"" />
                                                </link-entity>
                                                <filter>
                                                    <condition attribute=""msevtmgt_eventid"" operator=""eq"" value=""{eventId}"" />
                                                </filter>
                                            </entity>
                                        </fetch>";

                DbConnection dbConnect = new DbConnection();

                ServiceClient conn = dbConnect.ConnectToDataverse(log);
                FetchExpression fetchQuery = new FetchExpression(fetchTagsXml);
                var eventTagsCollection = await conn.RetrieveMultipleAsync(fetchQuery);
                List<string> eventTags = new List<string>();
                foreach (var eventTag in eventTagsCollection.Entities)
                {
                    foreach (var eventTagAttribute in eventTag.Attributes)
                    {
                        if (eventTagAttribute.Key == "eventTag")
                            eventTags.Add(((Microsoft.Xrm.Sdk.AliasedValue)eventTagAttribute.Value).Value.ToString());
                    }
                }

                return eventTags;
            }
            catch (Exception ex)
            {
                log.LogError($"While fetching event tags, exception is thrown and exception messages is : {ex.Message}");
                return null;
            }
        }

        private async Task<List<string>> getPrivateEvents(string userId, ILogger log)
        {
            try
            {
                string fetchPrivateEventXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                                        <fetch>
                                            <entity name=""dcuk_msevtmgt_event_contact"">
                                                <attribute name=""msevtmgt_eventid"" />
                                                <filter>
                                                    <condition attribute=""contactid"" operator=""eq"" value=""{userId}"" />
                                                </filter>
                                            </entity>
                                        </fetch>";

                DbConnection dbConnect = new DbConnection();

                ServiceClient conn = dbConnect.ConnectToDataverse(log);
                FetchExpression fetchQuery = new FetchExpression(fetchPrivateEventXml);
                var privateEventCollection = await conn.RetrieveMultipleAsync(fetchQuery);
                List<string> privateEvents = new List<string>();
                foreach (var privateEvent in privateEventCollection.Entities)
                {
                    foreach (var eventTagAttribute in privateEvent.Attributes)
                    {
                        if (eventTagAttribute.Key == "msevtmgt_eventid")
                            privateEvents.Add(eventTagAttribute.Value.ToString());
                    }
                }

                return privateEvents;
            }
            catch (Exception ex)
            {
                log.LogError($"While fetching private events, exception is thrown and exception messages is : {ex.Message}");
                return null;
            }
        }
        public async Task<List<Dictionary<string, object>>> getEvents(FetchCriteria fetchEvents, ILogger log, bool includeChilds = false)
        {
            try
            {
                DbConnection dbConnect = new DbConnection();
                ServiceClient conn = dbConnect.ConnectToDataverse(log);

                string fetchXml = PrepareFetchXML(fetchEvents, log);

                FetchExpression fetchQuery = new FetchExpression(fetchXml);

                var mainEventsCollection = await conn.RetrieveMultipleAsync(fetchQuery);

                List<Dictionary<string, object>> eventList = new List<Dictionary<string, object>>();

                foreach (var e in mainEventsCollection.Entities)
                {
                    Dictionary<string, object> eventDetails = new System.Collections.Generic.Dictionary<string, object>();
                    foreach (var fv in e.Attributes)
                    {
                        Object value;

                        if (fv.Value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                            value = ((Microsoft.Xrm.Sdk.OptionSetValue)fv.Value).Value;
                        else if (fv.Value.GetType() == typeof(Microsoft.Xrm.Sdk.AliasedValue))
                        {
                            value = ((Microsoft.Xrm.Sdk.AliasedValue)fv.Value).Value;
                            if (value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                value = ((Microsoft.Xrm.Sdk.OptionSetValue)value).Value;
                            else if (value.GetType() == typeof(Microsoft.Xrm.Sdk.EntityReference))
                                value = ((Microsoft.Xrm.Sdk.EntityReference)value).Id;
                        }
                        else
                            value = fv.Value;

                        if (fv.Key == "startDate")
                        {
                            DateTime startDt = DateTime.Parse(value.ToString());

                            eventDetails.Add("startDate", value);
                            eventDetails.Add("startDateUTC", startDt.ToUniversalTime());
                        }
                        else if (fv.Key == "endDate")
                        {
                            DateTime endDt = DateTime.Parse(value.ToString());

                            eventDetails.Add("endDate", value);
                            eventDetails.Add("endDateUTC", endDt.ToUniversalTime());
                        }
                        else if (fv.Key == "msevtmgt_eventimage") ;
                        else if (fv.Key == "customEventFormat")
                        {
                            eventDetails.Add("customEventFormat", e.FormattedValues[fv.Key]);
                        }
                        else
                            eventDetails.Add(fv.Key, value);

                        if (fv.Key == "eventId")
                        {
                            var tags = await getEventTags(value.ToString(), log);
                            eventDetails.Add("eventTags", tags);
                        }

                        if (fv.Key == "eventId" && includeChilds == true)
                        {
                            FetchCriteria fetchRelatedEvents = new FetchCriteria()
                            {
                                dcuk_makeeventprivate = null,
                                msevtmgt_baserecurrenteventid = value.ToString(),
                                redableEventId = null
                            };

                            string relatedEventsFetchXml = PrepareFetchXML(fetchRelatedEvents, log);

                            // log.LogInformation("Fetch XML for child events is : " + relatedEventsFetchXml);

                            FetchExpression relatedEventsFetchQuery = new FetchExpression(relatedEventsFetchXml);

                            var childEventsCollection = await conn.RetrieveMultipleAsync(relatedEventsFetchQuery);

                            if (childEventsCollection.Entities.Count != 0)
                            {
                                List<Object> childEvents = new List<Object>();

                                foreach (var childEntity in childEventsCollection.Entities)
                                {
                                    Dictionary<string, object> childEventDetails = new Dictionary<string, object>();
                                    foreach (var childFV in childEntity.Attributes)
                                    {
                                        Object childValue;
                                        if (childFV.Value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                            childValue = ((Microsoft.Xrm.Sdk.OptionSetValue)childFV.Value).Value;
                                        else if (childFV.Value.GetType() == typeof(Microsoft.Xrm.Sdk.AliasedValue))
                                        {
                                            childValue = ((Microsoft.Xrm.Sdk.AliasedValue)childFV.Value).Value;
                                            if (childValue.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                                childValue = ((Microsoft.Xrm.Sdk.OptionSetValue)childValue).Value;
                                            else if (childValue.GetType() == typeof(Microsoft.Xrm.Sdk.EntityReference))
                                                childValue = ((Microsoft.Xrm.Sdk.EntityReference)childValue).Id;
                                        }
                                        else
                                            childValue = childFV.Value;

                                        if (childFV.Key == "startDate")
                                        {
                                            DateTime startDt = DateTime.Parse(childValue.ToString());

                                            childEventDetails.Add("startDate", childValue);
                                            childEventDetails.Add("startDateUTC", startDt.ToUniversalTime());
                                        }
                                        else if (childFV.Key == "endDate")
                                        {
                                            DateTime endDt = DateTime.Parse(childValue.ToString());

                                            childEventDetails.Add("endDate", childValue);
                                            childEventDetails.Add("endDateUTC", endDt.ToUniversalTime());
                                        }
                                        else if (childFV.Key == "msevtmgt_eventimage") ;
                                        else if (fv.Key == "customEventFormat")
                                        {
                                            eventDetails.Add("customEventFormat", e.FormattedValues[fv.Key]);
                                        }
                                        else
                                            childEventDetails.Add(childFV.Key, childValue);

                                        if (childFV.Key == "eventId")
                                        {
                                            var tags = await getEventTags(childValue.ToString(), log);
                                            childEventDetails.Add("eventTags", tags);
                                        }


                                    }

                                    childEvents.Add(childEventDetails);
                                }
                                eventDetails.Add("childEvents", childEvents);
                            }
                            else
                                eventDetails.Add("childEvents", null);
                        }
                    }
                    eventList.Add(eventDetails);
                }

                return eventList;
            }
            catch (Exception ex)
            {
                log.LogInformation("Exception messages is : ", ex.Message);
                return null;
            }
        }

        private string PrepareFetchXML(FetchCriteria fetchCriteria, ILogger log)
        {
            string fetchXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                                <fetch>
                                    <entity name=""msevtmgt_event"">
                                        <attribute name=""msevtmgt_allowanonymousregistrations"" alias=""allowAnonymousRegistrations"" />
                                        <attribute name=""msevtmgt_allowcustomagenda"" alias=""allowCustomAgenda"" />
                                        <attribute name=""msevtmgt_expectedoutcome"" alias=""expectedOutcome"" />
                                        <attribute name=""msevtmgt_manageregistrationcount"" alias=""manageRegistrationCount"" />
                                        <attribute name=""owningbusinessunit"" alias=""businessUnit"" />
                                        <attribute name=""msevtmgt_description"" alias=""description"" />
                                        <attribute name=""msevtmgt_publiceventurl"" alias=""publicEventUrl"" />
                                        <attribute name=""msevtmgt_eventtimezonename"" alias=""timeZoneName"" />
                                        <attribute name=""msevtmgt_eventstartdate"" alias=""startDate"" />
                                        <attribute name=""msevtmgt_eventenddate"" alias=""endDate"" />
                                        <attribute name=""msevtmgt_eventtype"" alias=""eventType"" />
                                        <attribute name=""msevtmgt_eventtimezone"" alias=""timeZone"" />
                                        <attribute name=""msevtmgt_eventid"" alias=""eventId"" />
                                        <attribute name=""msevtmgt_enablemultiattendeeregistration"" alias=""enableMultiAttendeeRegistration"" />
                                        <attribute name=""msevtmgt_setregistrationsenddate"" alias=""setRegistrationEndDate"" />
                                        <attribute name=""msevtmgt_enablecaptcha"" alias=""enableCaptcha"" />
                                        <attribute name=""msevtmgt_formpagejavascriptcode"" alias=""registrationForm""/>
                                        <attribute name=""msevtmgt_name"" alias=""eventName"" />
                                        <attribute name=""msevtmgt_maximumeventcapacity"" alias=""maxCapacity"" />
                                        <attribute name=""msevtmgt_language"" alias=""eventLanguage"" />
                                        <attribute name=""msevtmgt_readableeventid"" alias=""readableEventId"" />
                                        <attribute name=""msevtmgt_eventformat"" alias=""eventFormat"" />
                                        <attribute name=""msevtmgt_autoregisterwaitlistitems"" alias=""autoregisterWaitlistItems"" />
                                        <attribute name=""msevtmgt_room"" alias=""room"" />
                                        <attribute name=""msevtmgt_transactioncurrencyid"" />
                                        <attribute name=""msevtmgt_maxnumberofregistrations"" />
                                        <attribute name=""msevtmgt_stopwebsiteregistrationson"" alias=""stopRegistrationDate""/>
                                        <attribute name=""dcuk_eventformat"" alias=""customEventFormat"" />
                                        <attribute name=""msevtmgt_eventimage""/>
                                        <link-entity name=""msdyncrm_file"" from=""msdyncrm_fileid"" to=""msevtmgt_eventimage"" link-type=""outer"" alias=""ac"">
                                            <attribute name=""msdyncrm_blobcdnuri"" alias=""image"" />
                                        </link-entity >
                                        <attribute name=""msevtmgt_building"" alias=""building"" />
                                        <attribute name=""dcuk_makeeventprivate"" alias=""privateEvent"" />
                                        <filter>
                                            <condition attribute=""statecode"" operator=""eq"" value=""0"" />
                                            <condition attribute=""msevtmgt_publishstatus"" operator=""eq"" value=""{Globals.PUBLISHED_EVENT_STATUS}"" />";

            if (fetchCriteria.dcuk_makeeventprivate == Globals.PRIVATE_EVENT)
            {
                if (!(fetchCriteria.userId == "null" || fetchCriteria.userId == null || string.IsNullOrEmpty(fetchCriteria.userId)))
                {
                    fetchXml += $@" <condition attribute=""dcuk_makeeventprivate"" operator=""eq"" value=""{Globals.PRIVATE_EVENT}"" />
                                    <condition attribute=""msevtmgt_eventid"" operator=""in"" value="""">";

                    List<string> privateEvents = getPrivateEvents(fetchCriteria.userId, log).Result;
                    if (privateEvents.Count > 0)
                    {
                        foreach (var eventId in privateEvents)
                            fetchXml += $@"<value>{eventId}</value>";
                    }
                    else
                        fetchXml += "<value />";

                    fetchXml += $@" </condition>";
                }
                else
                    return null;
            }
            else if (fetchCriteria.dcuk_makeeventprivate == Globals.PUBLIC_EVENT)
            {
                fetchXml += $@" <condition attribute=""dcuk_makeeventprivate"" operator=""eq"" value=""{Globals.PUBLIC_EVENT}"" />";
            }

            if (!(fetchCriteria.msevtmgt_baserecurrenteventid == "null" || fetchCriteria.msevtmgt_baserecurrenteventid == null || string.IsNullOrEmpty(fetchCriteria.msevtmgt_baserecurrenteventid)))
            {
                fetchXml += $@" <condition attribute=""msevtmgt_baserecurrenteventid"" operator=""eq"" value=""{fetchCriteria.msevtmgt_baserecurrenteventid}"" />
                                <condition attribute=""msevtmgt_eventstartdate"" operator= ""ge"" value = ""{ DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day}"" />";
            }
            else
            {
                if (!(fetchCriteria.redableEventId == "null" || fetchCriteria.redableEventId == null || string.IsNullOrEmpty(fetchCriteria.redableEventId)))
                    fetchXml += $@"<condition attribute=""msevtmgt_readableeventid"" operator=""eq"" value=""{fetchCriteria.redableEventId}"" />";
                else
                {
                    fetchXml += $@" <condition attribute=""msevtmgt_baserecurrenteventid"" operator=""null"" />
                                    <filter type=""or"">
                                        <condition attribute = ""msevtmgt_eventstartdate"" operator= ""ge"" value = ""{ DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day}"" />
                                        <condition attribute = ""msevtmgt_eventstartdate"" operator= ""null"" />
                                    </filter>";
                }
            }

            fetchXml += $@"</filter>
                           <order attribute=""msevtmgt_eventstartdate"" />
                        </entity>
                    </fetch>";

            return fetchXml;
        }

        public async Task<PurchaseInfo> getPurchaseInfo(string accessToken, string PurchaseId, ILogger log)
        {
            var response = GetTemporaryPurchaseDetails(accessToken, PurchaseId);
            if (response.IsSuccessStatusCode)
            {
                //var result = response.Content.ReadAsStringAsync().Result;
                var result = await response.Content.ReadAsStringAsync();
                var rawJSON = JsonConvert.DeserializeObject(result);
                if (((Newtonsoft.Json.Linq.JObject)rawJSON).ContainsKey("Result"))
                {
                    var resultFromJSON = ((Newtonsoft.Json.Linq.JObject)rawJSON)["Result"];
                    var resultValue = ((Newtonsoft.Json.Linq.JValue)resultFromJSON).Value;
                    PurchaseInfo purchaseInfo = JsonConvert.DeserializeObject<PurchaseInfo>(resultValue.ToString());

                    log.LogInformation($"Result is {purchaseInfo}");


                    return purchaseInfo;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                // Something went wrong. 
                // This most probably means that there is an issue with your configuration.

                return null;
            }
        }

        private HttpResponseMessage GetTemporaryPurchaseDetails(string accessToken, string purchaseId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(organizationUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var request = CreateTemporaryPurchaseDetailRequest(accessToken, purchaseId);

                return client.SendAsync(request).Result;
            }
        }

        public HttpRequestMessage CreateTemporaryPurchaseDetailRequest(string accessToken, string purchaseId)
        {
            var encodedRequestBody = JsonConvert.SerializeObject(new { PurchaseId = purchaseId });

            var request = new HttpRequestMessage(HttpMethod.Post, PURCHASEDETAILEDINFO);
            request.Content = new StringContent(encodedRequestBody, Encoding.UTF8, "application/json");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            return request;
        }

        public async Task<bool> AddOrganizationDeails(OrganizationDetails organizationDetails, ILogger log)
        {
            try
            {
                DbConnection dbConnection = new DbConnection();
                ServiceClient dbConn = dbConnection.ConnectToDataverse(log);
                Entity orgDetails = new Entity("dcuk_passpurchaseorganization");

                orgDetails["dcuk_name"] = organizationDetails.Name;
                orgDetails["dcuk_address1"] = organizationDetails.Address1;
                orgDetails["dcuk_address2"] = organizationDetails.Address2;
                orgDetails["dcuk_city"] = organizationDetails.City;
                orgDetails["dcuk_zipcode"] = organizationDetails.Zipcode;
                orgDetails["dcuk_state"] = organizationDetails.State;
                orgDetails["dcuk_country"] = organizationDetails.Country;
                orgDetails["dcuk_annualturnover"] = organizationDetails.AnnualTurnover;
                orgDetails["dcuk_readableeventid"] = organizationDetails.ReadableEventId;
                orgDetails["dcuk_purchaseid"] = organizationDetails.PurchaseId;

                UpsertRequest request = new UpsertRequest()
                {
                    Target = orgDetails
                };

                UpsertResponse response = (UpsertResponse)dbConn.Execute(request);
                if (response.RecordCreated)
                    log.LogInformation("Record created");
                else
                    log.LogInformation("Record updated");


                return true;
            }
            catch (FaultException faultException)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
