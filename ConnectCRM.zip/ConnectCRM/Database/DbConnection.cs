﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace EventsManagement.Database
{
    public class DbConnection
    {
        /*Maintains a single connection across requests. */
        public static ServiceClient DataverseConnection = null;
        public ServiceClient ConnectToDataverse(ILogger log)
        {
            try
            {
                if (DataverseConnection == null)
                {
                    string clientId = Environment.GetEnvironmentVariable("DataverseClientID", EnvironmentVariableTarget.Process);
                    string clientSecret = Environment.GetEnvironmentVariable("DataverseClientSecret", EnvironmentVariableTarget.Process);
                    string organizationUrl = Environment.GetEnvironmentVariable("DataverseOrgURL", EnvironmentVariableTarget.Process);

                    string connectionString = $@"AuthType=ClientSecret;url={organizationUrl};ClientId={clientId};ClientSecret={clientSecret}";

                    // log.LogInformation("Connection String : " + connectionString);

                    ServiceClient conn = new ServiceClient(connectionString);
                    // IOrganizationService serviceproxy = conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : throw new Exception("Not Connected. CDS OrganizationWebProxyClient is null");

                    if (conn != null)
                        DataverseConnection = conn;
                    else
                    {
                        DataverseConnection = null;
                        throw new Exception("Not able to Connect to Dataverse. CDS OrganizationWebProxyClient is null");
                    }
                }

                return DataverseConnection;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public string AuthenticateToDynamics365()
        {
            string clientId = Environment.GetEnvironmentVariable("DataverseClientID", EnvironmentVariableTarget.Process);
            string clientSecret = Environment.GetEnvironmentVariable("DataverseClientSecret", EnvironmentVariableTarget.Process);
            string organizationUrl = Environment.GetEnvironmentVariable("DataverseOrgURL", EnvironmentVariableTarget.Process);
            string tenantId = Environment.GetEnvironmentVariable("TenantId", EnvironmentVariableTarget.Process);

            var authContext = new AuthenticationContext($"https://login.microsoftonline.com/{tenantId}", false);

            var credential = new ClientCredential(clientId, clientSecret);

            var authenticationResult = authContext.AcquireTokenAsync(organizationUrl, credential).Result;

            return authenticationResult.AccessToken;
        }
    }
}
