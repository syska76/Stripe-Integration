﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

using EventsManagement.Services;
using EventsManagement.Utils;
using System.Collections.Generic;
using EventsManagement.Database;

namespace EventsManagement
{
    public class FetchCriteria
    {
        public string dcuk_makeeventprivate { get; set; }
        public string userId { get; set; } = null;
        public string msevtmgt_baserecurrenteventid { get; set; }
        public string redableEventId { get; set; }
    }

    public class EventProcessing
    {
        public async Task<List<Dictionary<string, object>>> getEvents(FetchCriteria fetchCriteria, ILogger log, bool includeChilds = false)
        {
            EventManagementService evtMgtService = new EventManagementService();
            List<Dictionary<string, object>> events = await evtMgtService.getEvents(fetchCriteria, log, includeChilds);

            if (events != null)
            {
                //string sendEvents = JsonConvert.SerializeObject(events);

                //return new OkObjectResult(sendEvents);
                return events;
            }
            else
            {
                log.LogError("Something went wrong while fetching events from EventProcessing.getEvents.");
                // return new StatusCodeResult(500);
                return null;
            }
        }
    }

    public static class EventsController
    {
        /* In a funciton one parameter can be passed in the query string
        * type = training/event/all and default value is all
        */

        [FunctionName("publicevents")]
        public static async Task<IActionResult> PublicEvents(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "publicevents")] HttpRequest req, ILogger log)
        {
            log.LogInformation("publicevents - HTTP trigger function processing a request.");

            //log.LogInformation($"Username: {req.HttpContext.User.Identity.Name}\nIsAuthenticated: {req.HttpContext.User.Identity.IsAuthenticated.ToString()}<=>Authenticated Type: {req.HttpContext.User.Identity.AuthenticationType}");

            //foreach(var claim in req.HttpContext.User.Claims)
            //{
            //    log.LogInformation($"{claim.Type}, {claim.Value}, {claim.ValueType}");
            //}

            try
            {
                // FetchCriteria should contains the parameter for fetching PUBLIC Events
                FetchCriteria fetchMainEvents = new FetchCriteria()
                {
                    dcuk_makeeventprivate = Globals.PUBLIC_EVENT,
                    msevtmgt_baserecurrenteventid = null,
                    redableEventId = null
                };

                EventProcessing evtProcess = new EventProcessing();
                List<Dictionary<string, object>> events = await evtProcess.getEvents(fetchMainEvents, log, false);

                //return await evtProcess.getEvents(fetchMainEvents, log, false);

                string sendEvents = JsonConvert.SerializeObject(events);

                return new OkObjectResult(sendEvents);
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong. The exception message is '{ex.Message}'");
                return new StatusCodeResult(500);
            }
        }

        /* In a funciton one parameter can be passed in the query string
         * type = training/event/all and default value is all
        */
        [FunctionName("privateevents")]
        public static async Task<IActionResult> PrivateEvents(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "privateevents")] HttpRequest req, ILogger log)
        {
            log.LogInformation("privateevents - HTTP trigger function processing a request.");
            string userId = req.Query["userid"];

            if (string.IsNullOrEmpty(userId) || userId == "undefined")
            {
                log.LogInformation("UserId parameter not passed. Please pass the UserId.");
                return new OkResult();
            }

            try
            {
                // FetchCriteria should contains the parameter for fetching PRIVATE Events
                FetchCriteria fetchMainEvents = new FetchCriteria()
                {
                    dcuk_makeeventprivate = Globals.PRIVATE_EVENT,
                    msevtmgt_baserecurrenteventid = null,
                    redableEventId = null,
                    userId = userId
                };

                EventProcessing evtProcess = new EventProcessing();
                //return await evtProcess.getEvents(fetchMainEvents, log, false);

                List<Dictionary<string, object>> events = await evtProcess.getEvents(fetchMainEvents, log, false);

                //return await evtProcess.getEvents(fetchMainEvents, log, false);

                string sendEvents = JsonConvert.SerializeObject(events);

                return new OkObjectResult(sendEvents);
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong. The exception message is '{ex.Message}'");
                return new StatusCodeResult(500);
            }
        }

        [FunctionName("eventdetails")]
        public static async Task<IActionResult> EventDetails(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "eventdetails")] HttpRequest req, ILogger log)
        {
            log.LogInformation("eventdetails - HTTP trigger function processing a request.");

            string readableeventid = req.Query["readableeventid"];

            //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            //dynamic data = JsonConvert.DeserializeObject(requestBody);
            //name = name ?? data?.name;
            string userId = req.Query["userid"];

            if (string.IsNullOrEmpty(userId) || userId == "undefined")
            {
                log.LogInformation("UserId parameter not passed.");
                userId = null;
            }

            if (string.IsNullOrEmpty(readableeventid))
                throw new InvalidDataException("You need to pass the Readable Event Id ('readableeventid') as parameter.");

            try
            {
                // FetchCriteria should contains the parameter for fetching PRIVATE Events
                FetchCriteria fetchMainEvents = new FetchCriteria()
                {
                    dcuk_makeeventprivate = null,
                    msevtmgt_baserecurrenteventid = null,
                    redableEventId = readableeventid,
                    userId = userId
                };

                EventProcessing evtProcess = new EventProcessing();
                //return await evtProcess.getEvents(fetchMainEvents, log, true);
                List<Dictionary<string, object>> events = await evtProcess.getEvents(fetchMainEvents, log, true);

                //return await evtProcess.getEvents(fetchMainEvents, log, false);

                string sendEvents = JsonConvert.SerializeObject(events[0]);

                return new OkObjectResult(sendEvents);
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong. The exception message is '{ex.Message}'");
                return new StatusCodeResult(500);
            }
        }

        /*This API endpoint is used to provided details of purchase info for summary in payment page*/
        [FunctionName("purchaseinfo")]
        public static async Task<IActionResult> PurchaseInfo(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "purchaseinfo")] HttpRequest req, ILogger log)
        {
            log.LogInformation("purchaseinfo - HTTP trigger function processing a request.");

            string purchaseId = req.Query["purchaseid"];

            //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            //dynamic data = JsonConvert.DeserializeObject(requestBody);
            //name = name ?? data?.name;

            if (string.IsNullOrEmpty(purchaseId) || purchaseId == "undefined")
            {
                log.LogInformation("PurchaseId parameter not passed.");
                purchaseId = null;
            }

            try
            {
                DbConnection dbConneciton = new DbConnection();

                string accessToken = dbConneciton.AuthenticateToDynamics365();
                var eventService = new EventManagementService();

                var purchaseInfo = await eventService.getPurchaseInfo(accessToken, purchaseId, log);

                return new OkObjectResult(purchaseInfo);
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong while getting purchase info details. The exception message is '{ex.Message}'");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        [FunctionName("registerorganization")]
        public static async Task<IActionResult> RegisterOrganization(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "registerorganization")] HttpRequest req, ILogger log)
        {
            log.LogInformation("registerorganization - HTTP trigger function processing a request.");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                dynamic data = JsonConvert.DeserializeObject<OrganizationDetails>(requestBody);
                //name = name ?? data?.name;

                EventManagementService service = new EventManagementService();
                service.AddOrganizationDeails(data, log);

                return new OkObjectResult(new { message = "New Organization Details added.", data = data });
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong while registering an Organization details. The exception message is '{ex.Message}'");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
