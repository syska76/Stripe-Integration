﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk.Query;
using System.Collections;
using System.Collections.Generic;

namespace ConnectCRM
{
    public static class ConnectCRM
    {
        private class FetchCriteria
        {
            public string msevtmgt_publishstatus { get; set; }
            public string phoenix_makeprivateevent { get; set; }
            public string phoenix_relatedevent { get; set; }
            public string eventId { get; set; }
        }

        /* In a funciton one parameter can be passed in the query string
         * type = training/event/all and default value is all
        */

        [FunctionName("publicevents")]
        public static async Task<IActionResult> PublicEvents(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "publicevents")] HttpRequest req, ILogger log)
        {
            log.LogInformation("publicevents - HTTP trigger function processing a request.");

            string type = req.Query["type"];

            //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            //dynamic data = JsonConvert.DeserializeObject(requestBody);
            //name = name ?? data?.name;

            type = string.IsNullOrEmpty(type) ? "all" : type;

            try
            {
                // FetchCriteria should contains the parameter for fetching PUBLIC Events
                FetchCriteria fetchMainEvents = new FetchCriteria()
                {
                    msevtmgt_publishstatus = "100000003",
                    phoenix_makeprivateevent = "0",
                    phoenix_relatedevent = "null"
                };

                return await getEvents(fetchMainEvents, log);
            }
            catch (Exception ex)
            {
                throw new InvalidDataException(ex.Message, ex);
            }

        }

        /* In a funciton one parameter can be passed in the query string
         * type = training/event/all and default value is all
        */
        [FunctionName("privateevents")]
        public static async Task<IActionResult> PrivateEvents(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "privateevents")] HttpRequest req, ILogger log)
        {
            log.LogInformation("privateevents - HTTP trigger function processing a request.");

            string type = req.Query["type"];

            //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            //dynamic data = JsonConvert.DeserializeObject(requestBody);
            //name = name ?? data?.name;

            type = string.IsNullOrEmpty(type) ? "all" : type;

            try
            {
                // FetchCriteria should contains the parameter for fetching PRIVATE Events
                FetchCriteria fetchMainEvents = new FetchCriteria()
                {
                    msevtmgt_publishstatus = "100000003",
                    phoenix_makeprivateevent = "1",
                    phoenix_relatedevent = "null"
                };

                return await getEvents(fetchMainEvents, log);
            }
            catch (Exception ex)
            {
                throw new InvalidDataException(ex.Message, ex);
            }

        }

        [FunctionName("eventdetails")]
        public static async Task<IActionResult> EventDetails(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "eventdetails")] HttpRequest req, ILogger log)
        {
            log.LogInformation("eventdetails - HTTP trigger function processing a request.");

            string redabaleeventid = req.Query["redabaleeventid"];

            //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            //dynamic data = JsonConvert.DeserializeObject(requestBody);
            //name = name ?? data?.name;

            if (string.IsNullOrEmpty(redabaleeventid))
                throw new InvalidDataException("You need to pass the RedableEventId ('redabaleeventid') as parameter.");

            try
            {
                // FetchCriteria should contains the parameter for fetching PRIVATE Events
                FetchCriteria fetchMainEvents = new FetchCriteria()
                {
                    msevtmgt_publishstatus = "100000003",
                    phoenix_makeprivateevent = "1",
                    phoenix_relatedevent = redabaleeventid
                };

                return await getEvents(fetchMainEvents, log);
            }
            catch (Exception ex)
            {
                throw new InvalidDataException(ex.Message, ex);
            }

        }

        private static async Task<IActionResult> getEvents(FetchCriteria fetchEvents, ILogger log, bool includeChilds = false)
        {
            try
            {
                ServiceClient conn = ConnectToDataverse();

                string fetchXml = PrepareFetchXML(fetchEvents);

                FetchExpression fetchQuery = new FetchExpression(fetchXml);

                var mainEventsCollection = await conn.RetrieveMultipleAsync(fetchQuery);

                List<Dictionary<string, object>> eventList = new List<Dictionary<string, object>>();

                foreach (var e in mainEventsCollection.Entities)
                {
                    Dictionary<string, object> eventDetails = new System.Collections.Generic.Dictionary<string, object>();
                    foreach (var fv in e.Attributes)
                    {
                        Object value;

                        if (fv.Value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                            value = ((Microsoft.Xrm.Sdk.OptionSetValue)fv.Value).Value;
                        else if (fv.Value.GetType() == typeof(Microsoft.Xrm.Sdk.AliasedValue))
                        {
                            value = ((Microsoft.Xrm.Sdk.AliasedValue)fv.Value).Value;
                            if (value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                value = ((Microsoft.Xrm.Sdk.OptionSetValue)value).Value;
                            else if (value.GetType() == typeof(Microsoft.Xrm.Sdk.EntityReference))
                                value = ((Microsoft.Xrm.Sdk.EntityReference)value).Id;
                        }
                        else
                            value = fv.Value;

                        eventDetails.Add(fv.Key, value);

                        if (fv.Key == "eventId")
                        {
                            FetchCriteria fetchRelatedEvents = new FetchCriteria()
                            {
                                msevtmgt_publishstatus = "100000003",
                                phoenix_makeprivateevent = fetchEvents.phoenix_makeprivateevent,
                                phoenix_relatedevent = value.ToString()
                            };

                            string relatedEventsFetchXml = PrepareFetchXML(fetchRelatedEvents);

                            // log.LogInformation("Fetch XML for child events is : " + relatedEventsFetchXml);

                            FetchExpression relatedEventsFetchQuery = new FetchExpression(relatedEventsFetchXml);

                            var childEventsCollection = await conn.RetrieveMultipleAsync(relatedEventsFetchQuery);

                            if (childEventsCollection.Entities.Count != 0)
                            {
                                List<Object> childEvents = new List<Object>();

                                foreach (var childEntity in childEventsCollection.Entities)
                                {
                                    Dictionary<string, object> childEventDetails = new Dictionary<string, object>();
                                    foreach (var childFV in childEntity.Attributes)
                                    {
                                        Object childValue;
                                        if (childFV.Value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                            childValue = ((Microsoft.Xrm.Sdk.OptionSetValue)childFV.Value).Value;
                                        else if (childFV.Value.GetType() == typeof(Microsoft.Xrm.Sdk.AliasedValue))
                                        {
                                            childValue = ((Microsoft.Xrm.Sdk.AliasedValue)childFV.Value).Value;
                                            if (childValue.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                                childValue = ((Microsoft.Xrm.Sdk.OptionSetValue)childValue).Value;
                                            else if (childValue.GetType() == typeof(Microsoft.Xrm.Sdk.EntityReference))
                                                childValue = ((Microsoft.Xrm.Sdk.EntityReference)childValue).Id;
                                        }
                                        else
                                            childValue = childFV.Value;

                                        childEventDetails.Add(childFV.Key, childValue);
                                    }

                                    childEvents.Add(childEventDetails);
                                }
                                eventDetails.Add("childEvents", childEvents);
                            }
                            else
                                eventDetails.Add("childEvents", null);
                        }
                    }
                    eventList.Add(eventDetails);
                }

                string sendEvents = JsonConvert.SerializeObject(eventList);

                return new OkObjectResult(sendEvents);
            }
            catch (Exception ex)
            {
                log.LogInformation("Exception messages is : ", ex.Message);
            }

            log.LogInformation("publicevents - HTTP trigger function processed a request.");

            return new OkObjectResult(false);

        }

        private static string PrepareFetchXML(FetchCriteria fetchCriteria)
        {
            string fetchXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                                <fetch top=""50"">
                                    <entity name=""msevtmgt_event"">
                                        <attribute name=""msevtmgt_allowanonymousregistrations"" alias=""allowAnonymousRegistrations"" />
                                        <attribute name=""msevtmgt_allowcustomagenda"" alias=""allowCustomAgenda"" />
                                        <attribute name=""adx_allowanonymousregistrations"" />
                                        <attribute name=""msevtmgt_manageregistrationcount"" />
                                        <attribute name=""owningbusinessunit"" alias=""businessUnit"" />
                                        <attribute name=""msevtmgt_description"" alias=""description"" />
                                        <attribute name=""msevtmgt_publiceventurl"" alias=""publicEventUrl"" />
                                        <attribute name=""msevtmgt_eventenddate"" alias=""endDate"" />
                                        <attribute name=""msevtmgt_eventtype"" alias=""eventType"" />
                                        <attribute name=""msevtmgt_eventtimezone"" alias=""timeZone"" />
                                        <attribute name=""msevtmgt_eventid"" alias=""eventId"" />
                                        <attribute name=""msevtmgt_enablemultiattendeeregistration"" alias=""enableMultiAttendeeRegistration"" />
                                        <attribute name=""msevtmgt_setregistrationsenddate"" alias=""setRegistrationEndDate"" />
                                        <attribute name=""msevtmgt_enablecaptcha"" alias=""enableCaptcha"" />
                                        <attribute name=""msdyncrm_marketingformid"" />
                                        <attribute name=""msevtmgt_name"" alias=""eventName"" />
                                        <attribute name=""msevtmgt_maximumeventcapacity"" />
                                        <attribute name=""msevtmgt_language"" alias=""eventLanguage"" />
                                        <attribute name=""msevtmgt_readableeventid"" alias=""readableEventId"" />
                                        <attribute name=""msevtmgt_eventformat"" alias=""eventFormat"" />
                                        <attribute name=""msevtmgt_eventtimezonename"" alias=""timeZoneName"" />
                                        <attribute name=""msevtmgt_autoregisterwaitlistitems"" alias=""autoregisterWaitlistItems"" />
                                        <attribute name=""msevtmgt_room"" alias=""room"" />
                                        <attribute name=""msevtmgt_transactioncurrencyid"" />
                                        <attribute name=""msevtmgt_eventstartdate"" alias=""startDate"" />
                                        <attribute name=""msevtmgt_maxnumberofregistrations"" />
                                        <attribute name=""msevtmgt_stopwebsiteregistrationson"" />
                                        <attribute name=""msevtmgt_eventimage"" alias=""image"" />
                                        <attribute name=""msevtmgt_building"" alias=""building"" />
                                        <attribute name=""phoenix_course"" alias=""course"" />
                                        <attribute name=""phoenix_makeprivateevent"" alias=""privateEvent"" />
                                        <filter>
                                            <condition attribute=""msevtmgt_publishstatus"" operator=""eq"" value=""{fetchCriteria.msevtmgt_publishstatus}"" />
                                            <condition attribute=""phoenix_makeprivateevent"" operator=""eq"" value=""{fetchCriteria.phoenix_makeprivateevent}"" />";

            if (fetchCriteria.phoenix_relatedevent == "null")
                fetchXml += $@" <condition attribute=""phoenix_relatedevent"" operator=""null"" />";
            else
                fetchXml += $@"<condition attribute=""phoenix_relatedevent"" operator=""eq"" value=""{fetchCriteria.phoenix_relatedevent}"" />";

            fetchXml += $@"</filter>
                                       <order attribute=""msevtmgt_eventstartdate"" />
                            </entity>
                        </fetch>";

            return fetchXml;
        }

        private static ServiceClient ConnectToDataverse()
        {
            try
            {
                //string clientId = Environment.GetEnvironmentVariable("DataverseClientID", EnvironmentVariableTarget.Process);
                //string clientSecret = Environment.GetEnvironmentVariable("DataverseClientSecret", EnvironmentVariableTarget.Process);
                //string organizationUrl = Environment.GetEnvironmentVariable("DataverseOrgURL", EnvironmentVariableTarget.Process);
                string clientId = "35278230-56da-4e51-9431-816a6d20efb0";
                string clientSecret = "72s8Q~xaocnjVtQ3gn3DwJoHGg-e~gMgSjOOzcMw";
                string organizationUrl = "https://vlmarketing.crm8.dynamics.com/";

                string connectionString = $@"AuthType=ClientSecret;url={organizationUrl};ClientId={clientId};ClientSecret={clientSecret}";



                ServiceClient conn = new ServiceClient(connectionString);
                // IOrganizationService serviceproxy = conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : throw new Exception("Not Connected. CDS OrganizationWebProxyClient is null");
                return conn != null ? conn : throw new Exception("Not Connected. CDS OrganizationWebProxyClient is null");

            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
