﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Stripe;
using System.IO;
using EventsManagement.Database;
using EventsManagement.Services;

namespace EventManagement
{
    public class Item
    {
        [JsonProperty("readableeventid")]
        public string ReadableEventId { get; set; }
        [JsonProperty("purchaseid")]
        public Guid PurchaseId { get; set; }
    }

    public class PaymentIntentCreateRequest
    {
        [JsonProperty("items")]
        public Item[] Items { get; set; }
    }



    public class PurchaseDetailedInfo
    {
        public PurchaseInfo Result { get; set; }
    }

    public static class PaymentGatewayController
    {
        /// <summary>
        /// The route to trigger the `msevtmgt_FinalizeExternalRegistrationRequest` custom action.
        /// </summary>
        private const string FINALIZE_REGISTRATION_ROUTE = "/api/data/v9.0/msevtmgt_FinalizeExternalRegistrationRequest";
        private const string PURCHASEDETAILEDINFO = "/api/data/v9.0/msevtmgt_ListDetailedPurchaseInfo ";

        /// <summary>
        /// The base URL of your organization.
        /// </summary>
        static string organizationUrl = Environment.GetEnvironmentVariable("DataverseOrgURL", EnvironmentVariableTarget.Process);

        [FunctionName("stripepreparation")]
        public static async Task<IActionResult> StripePreparation(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "stripepreparation")] HttpRequest req, ILogger log)
        {
            log.LogInformation("stripepreparation - HTTP trigger function processing a payment request.");

            var content = await new StreamReader(req.Body).ReadToEndAsync();

            log.LogInformation($"stripepreparation - body received is {content}");

            PaymentIntentCreateRequest paymentIntentRequest = JsonConvert.DeserializeObject<PaymentIntentCreateRequest>(content);

            try
            {
                string stripePrivateKey = Environment.GetEnvironmentVariable("Sripe_PrivateKey", EnvironmentVariableTarget.Process);
                //StripeConfiguration.ApiKey = "sk_test_51LmaZYSAHCWIZEPXrJsl0md2JpDUfzgxrWpcBhq8iHQzXytMB4Dl5aCvROB8WJAI7wAIpcG7wODx5X2QpauOdaIc00WjdHEtEl";
                StripeConfiguration.ApiKey = stripePrivateKey;
                string PurchaseId = paymentIntentRequest.Items[0].PurchaseId.ToString();
                string ReadableEventId = paymentIntentRequest.Items[0].ReadableEventId;

                log.LogInformation($"'ReadableEventId': {ReadableEventId} && 'PurchaseId' : {PurchaseId}");

                Dictionary<string, string> metaData = new Dictionary<string, string>();
                metaData.Add("PurchaseId", PurchaseId);
                metaData.Add("ReadableEventId", ReadableEventId);

                DbConnection dbConneciton = new DbConnection();

                string accessToken = dbConneciton.AuthenticateToDynamics365();
                var response = GetTemporaryPurchaseDetails(accessToken, PurchaseId);
                if (response.IsSuccessStatusCode)
                {
                    //var result = response.Content.ReadAsStringAsync().Result;
                    var result = await response.Content.ReadAsStringAsync();
                    var rawJSON = JsonConvert.DeserializeObject(result);
                    if (((Newtonsoft.Json.Linq.JObject)rawJSON).ContainsKey("Result"))
                    {
                        var resultFromJSON = ((Newtonsoft.Json.Linq.JObject)rawJSON)["Result"];
                        var resultValue = ((Newtonsoft.Json.Linq.JValue)resultFromJSON).Value;
                        PurchaseInfo purchaseInfo = JsonConvert.DeserializeObject<PurchaseInfo>(resultValue.ToString());

                        log.LogInformation($"Result is {purchaseInfo}");

                        PaymentIntentService paymentIntentService = new PaymentIntentService();
                        var paymentIntent = paymentIntentService.Create(new PaymentIntentCreateOptions
                        {
                            Amount = (long)(decimal.Parse(purchaseInfo.Amount) * 100),
                            Currency = purchaseInfo.isoCurrencyCode,
                            AutomaticPaymentMethods = new PaymentIntentAutomaticPaymentMethodsOptions
                            {
                                Enabled = true,
                            },
                            Metadata = metaData
                        });

                        return new JsonResult(new { clientSecret = paymentIntent.ClientSecret });
                    }
                    else
                    {
                        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                    }
                }
                else
                {
                    // Something went wrong. 
                    // This most probably means that there is an issue with your configuration.

                    return new BadRequestResult();
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong. The exception message is '{ex.Message}'");
                return new StatusCodeResult(500);
            }
        }

        [FunctionName("paymentprocessed")]
        public static async Task<IActionResult> PaymentProcess(
        [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "paymentprocessed")] HttpRequest req, ILogger log)
        {
            log.LogInformation("paymentprocess - HTTP trigger function processing a payment request.");

            //log.LogInformation($"Username: {req.HttpContext.User.Identity.Name}\nIsAuthenticated: {req.HttpContext.User.Identity.IsAuthenticated.ToString()}<=>Authenticated Type: {req.HttpContext.User.Identity.AuthenticationType}");

            //foreach(var claim in req.HttpContext.User.Claims)
            //{
            //    log.LogInformation($"{claim.Type}, {claim.Value}, {claim.ValueType}");
            //}

            string purchaseId = req.Query["purchaseid"];
            log.LogInformation($"PurchaseId={purchaseId}");

            if (string.IsNullOrEmpty(purchaseId) || purchaseId == "undefined")
            {
                log.LogInformation("PurchaseId parameter not passed. Please pass the purchaseid.");
                return new OkResult();
            }

            string userId = req.Query["userid"];

            if (string.IsNullOrEmpty(userId) || userId == "undefined")
            {
                log.LogInformation("UserId parameter not passed, it will be considered as ''.");
                userId = "";
            }

            string readableEventId = req.Query["readableeventid"];

            if (string.IsNullOrEmpty(readableEventId) || readableEventId == "undefined")
            {
                log.LogInformation("ReadableEventId parameter not passed. Please pass the ReadableEventId.");
                return new OkResult();
            }

            try
            {
                var finalizeRegistrationData = new Dictionary<string, string>
                                                {
                                                    { "PurchaseId", purchaseId },
                                                    { "ReadableEventId", readableEventId },
                                                    { "UserId", userId }
                                                };

                DbConnection dbConneciton = new DbConnection();
                string accessToken = dbConneciton.AuthenticateToDynamics365();
                var response = FinalizeRegistration(accessToken, finalizeRegistrationData);

                if (response.IsSuccessStatusCode)
                {
                    //var result = response.Content.ReadAsStringAsync().Result;
                    var result = await response.Content.ReadAsStringAsync();
                    // Handle response. 
                    // The respones contains an attribute called 'status' which indicates
                    // if the registration was successful or not. 

                    log.LogInformation($"Result is {result}");
                }
                else
                {
                    // Something went wrong. 
                    // This most probably means that there is an issue with your configuration.
                }
                return new OkResult();
            }
            catch (Exception ex)
            {
                log.LogError($"Something went wrong. The exception message is '{ex.Message}'");
                return new StatusCodeResult(500);
            }

        }

        private static HttpResponseMessage FinalizeRegistration(string accessToken, Dictionary<string, string> finalizeRegistrationData)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(organizationUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var request = CreateFinalizeRegistrationRequest(accessToken, finalizeRegistrationData);

                return client.SendAsync(request).Result;
            }
        }

        public static HttpRequestMessage CreateFinalizeRegistrationRequest(string accessToken, Dictionary<string, string> finalizeRegistrationData)
        {
            var encodedRequestBody = JsonConvert.SerializeObject(finalizeRegistrationData);

            var request = new HttpRequestMessage(HttpMethod.Post, FINALIZE_REGISTRATION_ROUTE);
            request.Content = new StringContent(encodedRequestBody, Encoding.UTF8, "application/json");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            return request;
        }

        private static HttpResponseMessage GetTemporaryPurchaseDetails(string accessToken, string purchaseId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(organizationUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var request = CreateTemporaryPurchaseDetailRequest(accessToken, purchaseId);

                return client.SendAsync(request).Result;
            }
        }

        public static HttpRequestMessage CreateTemporaryPurchaseDetailRequest(string accessToken, string purchaseId)
        {
            var encodedRequestBody = JsonConvert.SerializeObject(new { PurchaseId = purchaseId });

            var request = new HttpRequestMessage(HttpMethod.Post, PURCHASEDETAILEDINFO);
            request.Content = new StringContent(encodedRequestBody, Encoding.UTF8, "application/json");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            return request;
        }
    }
}
