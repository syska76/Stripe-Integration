﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventsManagement.Utils
{
    public static class Globals
    {
        public const string PUBLISHED_EVENT_STATUS = "100000003";
        public const string PRIVATE_EVENT = "1";
        public const string PUBLIC_EVENT = "0";
    }
}
