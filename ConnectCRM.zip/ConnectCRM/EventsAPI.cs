﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EventManagement
{
    public class EventTag
    {
        public string id { get; set; }
        public string topic { get; set; }
    }
    public class EventsAPI
    {
        private static ServiceClient dbConnection = null;

        /*This API endpoint is created for Tobby to develop the frontend for event portal
         At present, the connection details (Application user details) is kept as hard-coded but later on needs to be shifted to environemnt
        or common host parameters.
        This method has been developed on AD-HOC BASIS
        */
        [FunctionName("eventlist")]
        public static async Task<IActionResult> eventlist(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "eventlist")] HttpRequest req, ILogger log)
        {
            log.LogInformation("eventlist - HTTP trigger function processing a request.");

            //log.LogInformation($"Username: {req.HttpContext.User.Identity.Name}\nIsAuthenticated: {req.HttpContext.User.Identity.IsAuthenticated.ToString()}<=>Authenticated Type: {req.HttpContext.User.Identity.AuthenticationType}");

            //foreach(var claim in req.HttpContext.User.Claims)
            //{
            //    log.LogInformation($"{claim.Type}, {claim.Value}, {claim.ValueType}");
            //}
            try
            {
                List<Dictionary<string, object>> events = await GetAllEventsFromDB(log);
                string sendEvents = JsonConvert.SerializeObject(events);

                return new OkObjectResult(sendEvents);
            }
            catch (Exception e)
            {
                log.LogError($"Something went wrong in eventslist API endpoint and exception message is '{e.Message}'");
                return new StatusCodeResult(500);
            }
        }

        private static ServiceClient GetDbConnection(ILogger log)
        {
            try
            {
                if (dbConnection == null)
                {
                    string clientId = "b26dc5bf-8fe9-4fb2-9e4b-a728998fdfb1";
                    string clientSecret = "x7k8Q~sbfCeO~bzXBpsBjux2RRgWlTxUYDHDPahH";
                    string organizationUrl = "https://ncvo.crm4.dynamics.com/";

                    string connectionString = $@"AuthType=ClientSecret;url={organizationUrl};ClientId={clientId};ClientSecret={clientSecret}";

                    log.LogInformation("Connection String for Events Listing API endpoint is : " + connectionString);

                    ServiceClient conn = new ServiceClient(connectionString);
                    dbConnection = conn;
                }

                return dbConnection;
            }
            catch (Exception e)
            {
                log.LogError($"Something went wrong in eventslist API endpoint (GetDbConnection Method) and exception message is '{e.Message}'");
                throw e;
            }
        }

        private static async Task<List<Dictionary<string, object>>> GetAllEventsFromDB(ILogger log)
        {
            string fetchXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                                <fetch>
                                    <entity name=""msevtmgt_event"">
                                        <attribute name=""msevtmgt_name"" alias=""title"" />
                                        <attribute name=""msevtmgt_eventtype"" alias=""type"" />
                                        <attribute name=""msevtmgt_description"" alias=""description"" />
                                        <attribute name=""dcuk_makeeventprivate"" alias=""privateEvent"" />
                                        <attribute name=""msevtmgt_publiceventurl"" alias=""link"" />
                                        <attribute name=""msevtmgt_eventstartdate"" alias=""startDate"" />
                                        <attribute name=""msevtmgt_eventenddate"" alias=""endDate"" />
                                        <attribute name=""msevtmgt_eventtimezonename"" alias=""timeZoneName"" />
                                        <attribute name=""dcuk_eventformat"" alias=""format"" />
                                        <attribute name=""msevtmgt_expectedoutcome"" alias=""shortDescription"" />
                                        <filter>
                                            <condition attribute=""statecode"" operator=""eq"" value=""0"" />
                                            <condition attribute=""msevtmgt_publishstatus"" operator=""eq"" value=""100000003"" />
                                        </filter>
                                        <order attribute=""msevtmgt_eventstartdate"" />
                                    </entity>
                                </fetch>";
            try
            {
                ServiceClient conn = GetDbConnection(log);

                FetchExpression fetchQuery = new FetchExpression(fetchXml);
                var eventsCollection = await conn.RetrieveMultipleAsync(fetchQuery);

                List<Dictionary<string, object>> eventList = new List<Dictionary<string, object>>();
                bool flag = true;

                foreach (var e in eventsCollection.Entities)
                {
                    Dictionary<string, object> eventDetails = new System.Collections.Generic.Dictionary<string, object>();

                    eventDetails.Add("full", flag);
                    flag = !flag;

                    foreach (var fv in e.Attributes)
                    {
                        Object value;

                        if (fv.Value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                            value = ((Microsoft.Xrm.Sdk.OptionSetValue)fv.Value).Value;
                        else if (fv.Value.GetType() == typeof(Microsoft.Xrm.Sdk.AliasedValue))
                        {
                            value = ((Microsoft.Xrm.Sdk.AliasedValue)fv.Value).Value;
                            if (value.GetType() == typeof(Microsoft.Xrm.Sdk.OptionSetValue))
                                value = ((Microsoft.Xrm.Sdk.OptionSetValue)value).Value;
                            else if (value.GetType() == typeof(Microsoft.Xrm.Sdk.EntityReference))
                                value = ((Microsoft.Xrm.Sdk.EntityReference)value).Id;
                        }
                        else
                            value = fv.Value;

                        if (fv.Key == "privateEvent")
                            eventDetails.Add("private", value);
                        else if (fv.Key == "type")
                        {
                            eventDetails.Add("type", e.FormattedValues[fv.Key]);
                        }
                        else if (fv.Key == "msevtmgt_eventid")
                        {
                            var tags = await GetEventTags(value.ToString(), log);
                            eventDetails.Add("topics", tags);
                            eventDetails.Add("id", value);
                        }
                        else if (fv.Key == "format")
                        {
                            eventDetails.Add("tag", e.FormattedValues[fv.Key]);
                        }
                        else if (fv.Key == "startDate")
                        {
                            DateTime startDt = DateTime.Parse(value.ToString());

                            //eventDetails.Add("startDate", startDt.ToString("o"));
                            eventDetails.Add("startDate", startDt.ToUniversalTime().ToString("o"));
                        }
                        else if (fv.Key == "endDate")
                        {
                            DateTime endDt = DateTime.Parse(value.ToString());

                            //eventDetails.Add("endDate", endDt.ToString("o"));
                            eventDetails.Add("endDate", endDt.ToUniversalTime().ToString("o"));
                        }
                        else
                            eventDetails.Add(fv.Key, value);
                    }
                    eventList.Add(eventDetails);
                }
                return eventList;
            }
            catch (Exception ex)
            {
                log.LogInformation("Exception messages is : ", ex.Message);
                return null;
            }
        }

        private static async Task<List<EventTag>> GetEventTags(string eventId, ILogger log)
        {
            try
            {
                string fetchTagsXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                                        <fetch>
                                            <entity name=""dcuk_msevtmgt_event_dcuk_eventtags"">
                                                <attribute name=""dcuk_eventtagsid"" />
                                                <link-entity name=""dcuk_eventtags"" from=""dcuk_eventtagsid"" to=""dcuk_eventtagsid"" link-type=""inner"" >
                                                    <attribute name = ""dcuk_name""  alias=""eventTag"" />
                                                </link-entity>
                                                <filter>
                                                    <condition attribute=""msevtmgt_eventid"" operator=""eq"" value=""{eventId}"" />
                                                </filter>
                                            </entity>
                                        </fetch>";

                ServiceClient conn = GetDbConnection(log);

                FetchExpression fetchQuery = new FetchExpression(fetchTagsXml);
                var eventTagsCollection = await conn.RetrieveMultipleAsync(fetchQuery);
                List<EventTag> eventTags = new List<EventTag>();
                foreach (var eventTag in eventTagsCollection.Entities)
                {
                    EventTag tag = new EventTag();
                    foreach (var eventTagAttribute in eventTag.Attributes)
                    {
                        if (eventTagAttribute.Key == "eventTag")
                            tag.topic = ((Microsoft.Xrm.Sdk.AliasedValue)eventTagAttribute.Value).Value.ToString();
                        else if (eventTagAttribute.Key == "dcuk_eventtagsid")
                            tag.id = eventTagAttribute.Value.ToString();
                    }
                    eventTags.Add(tag);
                }

                return eventTags;
            }
            catch (Exception ex)
            {
                log.LogError($"While fetching event tags, exception is thrown and exception messages is : {ex.Message}");
                return null;
            }
        }
    }
}
