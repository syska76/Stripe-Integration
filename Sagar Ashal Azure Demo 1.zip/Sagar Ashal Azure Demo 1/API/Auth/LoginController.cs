﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Sagar_Ashal_Azure_Demo_1.Core;
using Sagar_Ashal_Azure_Demo_1.Extensions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Sagar_Ashal_Azure_Demo_1.API.Auth
{
    public class LoginController : Base.Controller
    {
        public LoginController(Bootstrap wrapper) : base(wrapper)
        {

        }

        [FunctionName("Auth_Login")]
        public async Task<IActionResult> Login(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "auth/login")] HttpRequest req, ILogger log)
        {

            return await Function.Execute(req, async () =>
            {
                var request = await req.Parse< LoginRequest, LoginValidator>();

                var service = new LoginService();

                var requestIP = req.HttpContext.Connection.RemoteIpAddress.ToString();

                var response = await service.Login(request.Value, requestIP);
                return new APIResult(HttpStatusCode.OK, response);
            });

        }

       /* [FunctionName("Auth_Status")]
        public async Task<IActionResult> Status(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "auth/status")] HttpRequest req, ILogger log)
        {
            {
                return await Function.Execute(req, async () =>
                {
                    var service = new LoginService();
                    var token = req.Headers.ContainsKey("token") ?
                        req.Headers["token"] :
                        throw new Sagar_Ashal_Azure_Demo_1.Exceptions.UnauthorizedException("Session Expired");
                    var response = await service.Status(token);
                    return new APIResult(HttpStatusCode.OK, response);
                });
            }
        }*/
    }
}
