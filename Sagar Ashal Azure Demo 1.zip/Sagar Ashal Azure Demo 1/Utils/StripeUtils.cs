﻿using Microsoft.Xrm.Sdk;
using Stripe.Checkout;
using Stripe;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using Sagar_Ashal_Azure_Demo_1.Base;
using Sagar_Ashal_Azure_Demo_1.Common.Models;
namespace Sagar_Ashal_Azure_Demo_1.Utils
{
    public static class StripeUtils
    {
        public static Task<Session> CreateCheckoutSession(string name, int price)
        {
            var options = new SessionCreateOptions
            {
                //Metadata = new Dictionary<string, string>()
                //{
                //    { "marketsearch_id", (order["advic_marketsearch"] as EntityReference).Id.ToString() },
                //    { "quotation_id",(order["advic_quotation"] as EntityReference).Id.ToString() },
                //    { "merchant_id",(order["advic_merchant"] as EntityReference).Id.ToString() },
                //    { "customer_id",(order["advic_customer"] as EntityReference).Id.ToString() },
                //    { "order_id",order.Id.ToString() },
                //},
                PaymentMethodTypes = new List<string> {
                    "card",
                },
                Mode = "payment",
                PaymentIntentData = new SessionPaymentIntentDataOptions()
                {
                    SetupFutureUsage = "off_session",
                    TransferData = new SessionPaymentIntentDataTransferDataOptions()
                    {
                        Amount = price * 10, //(long?)(price.UnitAmountDecimal - ((6 * price.UnitAmountDecimal) / 100)) * 100,
                       // Destination = connectedAccount,
                    },
                    //ApplicationFeeAmount = (6 * price.UnitAmount),
                },
                LineItems = new List<SessionLineItemOptions>()
                {
                    //new SessionLineItemOptions()
                    //{
                    //    Name = $"AlphaMerchants - Order #{order.GetAttributeValue<string>("advic_code")}",
                    //    Currency = "GBP",
                    //    Amount = (long?)((price.UnitAmountDecimal)*100),
                    //    Quantity = 1,
                    //},
                },
                Customer = name,
                SuccessUrl = Environment.GetEnvironmentVariable("STRIPE_CHECKOUT_SUCCESS_URL").Replace("ORDER_ID", name.ToString()),
                CancelUrl = Environment.GetEnvironmentVariable("STRIPE_CHECKOUT_CANCEL_URL"),
            };
            var service = new SessionService();
            var session = service.Create(options);
            return Task.FromResult(session);
        }
        public static async Task<Customer> CreateCustomer(ContactModel customer)
        {
            /*var invoiceAddress = new AddressOptions()
            {
                Line1 = customer.billing_addressline1,
                Line2 = customer.billing_addressline2,
                PostalCode = customer.billing_postalcode,
                City = customer.billing_city,
                Country = customer.billing_country
            };*/
            /*var shippingDetails = new ShippingOptions()
            {
                Name = customer.companyname,
                Address = invoiceAddress,
                Phone = customer.phone
            };*/
            /*var customerAddress = new AddressOptions()
            {
                Line1 = customer.addressline1,
                Line2 = customer.addressline2,
                PostalCode = customer.postalcode,
                City = customer.city,
                Country = customer.country
            };*/
            var options = new CustomerCreateOptions
            {
                Name = customer.name,
                Email = customer.email
            };
            var service = new CustomerService();
            return service.Create(options);
        }
    }
}