﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Stripe;

[assembly: FunctionsStartup(typeof(Sagar_Ashal_Azure_Demo_1.Core.Startup1))]

namespace Sagar_Ashal_Azure_Demo_1.Core
{
    public class Startup1 : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {

            builder.Services.AddSingleton<Bootstrap>();
            //builder.Services.AddSingleton<IFunctionFilter, LogFilter>();
            builder.Services.AddLogging();

            builder.Services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
                options.SerializerSettings.MissingMemberHandling = Newtonsoft.Json.MissingMemberHandling.Ignore;
            });
            SetupStripe();
        }
        private void SetupStripe()
        {
            var ConnectionMode = Constants.Stripe.CONNECTION_MODE;
            Constants.Stripe.API_KEY = "sk_test_51LhXcISEyqmVNeNCYkBhXpGFb8cNp6n7jzEWFhe0KDu7T3cGOTHykU6NgPWyVSdGA44doJy7hshlJiIZPkLVCOAn00MKYFmPOy";



            StripeConfiguration.ApiKey = Constants.Stripe.API_KEY;



            StripeConfiguration.StripeClient = new StripeClient(Constants.Stripe.API_KEY);



        }
    }
}
