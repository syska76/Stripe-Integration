﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Core
{
    public static class Constants
    {

        public static JsonSerializerSettings SerializerSettings = new JsonSerializerSettings()
        {
            ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
            NullValueHandling = NullValueHandling.Ignore,
            FloatFormatHandling = FloatFormatHandling.DefaultValue
        };

        public class Stripe
        {
            public static string API_KEY { get; set; }

            public static string CONNECTION_MODE { get => Environment.GetEnvironmentVariable("STRIPE_CONNECTION_MODE"); }

            public static string TAX_RATE { get; set; }
            public static class WebhookSecret
            {
                public static string CUSTOMER { get; set; }
                public static string ACCOUNT { get; set; }
                public static string CHECKOUT { get; set; }
            }
        }
    }
}
