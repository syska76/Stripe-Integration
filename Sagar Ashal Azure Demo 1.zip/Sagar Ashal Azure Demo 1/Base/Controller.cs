﻿using Sagar_Ashal_Azure_Demo_1.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Base
{
    public class Controller
    {
        protected readonly Bootstrap Function;
        public Controller(Bootstrap wrapper)
        {
            Function = wrapper;
        }
    }
}
