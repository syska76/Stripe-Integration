﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Exceptions
{
    public class BaseException : Exception
    {
        public HttpStatusCode statusCode = HttpStatusCode.InternalServerError;
        public string errorMessage;
        public Exception innerException;

        public BaseException(HttpStatusCode httpStatusCode, string message, Exception innerException) : base(message, innerException)
        {
            errorMessage = message;
            statusCode = httpStatusCode;
            this.innerException = innerException;
        }
    }
}
