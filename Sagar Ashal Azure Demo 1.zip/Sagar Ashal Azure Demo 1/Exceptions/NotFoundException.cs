﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Exceptions
{
    public class NotFoundException : BaseException
    {
        public NotFoundException(string message, Exception innerException = null) : base(HttpStatusCode.NotFound, message, innerException)
        {
        }
    }
}
