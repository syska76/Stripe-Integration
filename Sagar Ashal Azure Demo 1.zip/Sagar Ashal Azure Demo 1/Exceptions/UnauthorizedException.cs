﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Exceptions
{
    public class UnauthorizedException : BaseException
    {
        public UnauthorizedException(string message, Exception innerException = null) : base(HttpStatusCode.Unauthorized, message, innerException)
        {
        }
    }
}