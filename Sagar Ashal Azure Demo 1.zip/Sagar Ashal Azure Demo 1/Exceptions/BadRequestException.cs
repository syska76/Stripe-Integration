﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace Sagar_Ashal_Azure_Demo_1.Exceptions
{
    public class BadRequestException : BaseException
    {
        public BadRequestException(string message, Exception innerException = null) : base(HttpStatusCode.BadRequest, message, innerException)
        {
        }
    }
}
