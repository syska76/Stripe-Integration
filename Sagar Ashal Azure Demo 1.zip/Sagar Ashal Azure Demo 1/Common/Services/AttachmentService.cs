﻿using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sagar_Ashal_Azure_Demo_1.Common.Services
{
    public class AttachmentService : Base.Service
    {
        public static readonly string EntityLogicalName = "insta_instaregistration";

        public AttachmentService() : base(EntityLogicalName)
        {

        }
    }
}
