﻿using Microsoft.Xrm.Sdk;
using Sagar_Ashal_Azure_Demo_1.API.Auth;
using Sagar_Ashal_Azure_Demo_1.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Sagar_Ashal_Azure_Demo_1.Common.Services
{
    public class StripeService : Base.Service
    {
        //public static readonly string EntityLogicalName = "advic_order";
        //public StripeService() : base(EntityLogicalName) { }

        private Session session;
        public async Task<bool> Create(StripeModel request)
        {
            var result = await Create(request);

            var checkoutSession = await Utils.StripeUtils.CreateCheckoutSession(name:request.Name, price:request.Amount);

            return true;
        }
   
    }
}
