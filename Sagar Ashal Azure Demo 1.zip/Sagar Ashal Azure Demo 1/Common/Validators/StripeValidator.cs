﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Common.Validators
{
    internal class StripeValidator: Base.Validator<Models.StripeModel>
    {
        public StripeValidator()
        {
            RuleFor(x => x.Name).NotEmpty();
        }
    }
}
