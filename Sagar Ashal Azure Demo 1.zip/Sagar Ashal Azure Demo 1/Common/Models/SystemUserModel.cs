﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Common.Models
{
    public class SystemUserModel : Base.Model
    {
        public SystemUserModel(System.Guid id, string name) : base("systemuser")
        {
            this.id = id;
            this.name = name;
        }
    }
}
