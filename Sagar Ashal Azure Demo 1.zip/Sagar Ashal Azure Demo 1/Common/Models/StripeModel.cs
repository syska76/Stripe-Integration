﻿using Microsoft.Xrm.Sdk;
using Stripe;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sagar_Ashal_Azure_Demo_1.Common.Models
{
    public class StripeModel : Base.Model
    {

        public string Name { get; set; }
        public int Amount { get; set; }

    }
}
