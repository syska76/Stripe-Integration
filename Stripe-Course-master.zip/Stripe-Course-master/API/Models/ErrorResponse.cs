namespace API.Models
{
	public class ErrorResponse
	{
		public ErrorMessage ErrorMessage { get; set; }
	}
}