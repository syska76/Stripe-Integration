namespace API.Models
{
	public class ErrorMessage
	{
		public string Message { get; set; }
	}
}