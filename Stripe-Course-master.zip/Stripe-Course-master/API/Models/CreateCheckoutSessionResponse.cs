namespace API.Models
{
	public class CreateCheckoutSessionResponse
	{
		public string SessionId { get; set; }
		public string PublicKey { get; set; }
	}
}