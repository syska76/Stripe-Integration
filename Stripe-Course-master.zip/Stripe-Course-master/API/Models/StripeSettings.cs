namespace API.Models
{
	public class StripeSettings
	{
		public string PublicKey { get; set; }
		public string WHSecret { get; set; }
	}
}