export const environment = {
  production: true,
  baseUrl: '',
  homeUrl: '',
  successUrl: '',
  cancelUrl: '',
};
