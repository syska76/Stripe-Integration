export interface IAuth {}

export interface IUser {
  username: string;
  email: string;
  isSubscriber: boolean;
}
