import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membership-failure',
  templateUrl: './membership-failure.component.html',
  styleUrls: ['./membership-failure.component.scss']
})
export class MembershipFailureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
