import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membership-success',
  templateUrl: './membership-success.component.html',
  styleUrls: ['./membership-success.component.scss']
})
export class MembershipSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
