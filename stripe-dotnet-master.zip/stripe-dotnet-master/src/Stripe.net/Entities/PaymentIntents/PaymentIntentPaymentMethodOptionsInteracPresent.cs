// File generated from our OpenAPI spec
namespace Stripe
{
    public class PaymentIntentPaymentMethodOptionsInteracPresent : StripeEntity<PaymentIntentPaymentMethodOptionsInteracPresent>
    {
    }
}
