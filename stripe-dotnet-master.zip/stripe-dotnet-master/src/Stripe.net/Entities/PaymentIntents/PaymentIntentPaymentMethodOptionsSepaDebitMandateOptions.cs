// File generated from our OpenAPI spec
namespace Stripe
{
    public class PaymentIntentPaymentMethodOptionsSepaDebitMandateOptions : StripeEntity<PaymentIntentPaymentMethodOptionsSepaDebitMandateOptions>
    {
    }
}
