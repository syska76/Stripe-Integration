// File generated from our OpenAPI spec
namespace Stripe
{
    public class MandateMultiUse : StripeEntity<MandateMultiUse>
    {
    }
}
