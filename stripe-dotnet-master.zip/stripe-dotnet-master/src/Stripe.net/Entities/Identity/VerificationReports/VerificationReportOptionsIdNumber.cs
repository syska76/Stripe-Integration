// File generated from our OpenAPI spec
namespace Stripe.Identity
{
    public class VerificationReportOptionsIdNumber : StripeEntity<VerificationReportOptionsIdNumber>
    {
    }
}
