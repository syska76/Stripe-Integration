// File generated from our OpenAPI spec
namespace Stripe
{
    public class ChargePaymentMethodDetailsStripeAccount : StripeEntity<ChargePaymentMethodDetailsStripeAccount>
    {
    }
}
