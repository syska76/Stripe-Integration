// File generated from our OpenAPI spec
namespace Stripe
{
    public class ChargePaymentMethodDetailsCustomerBalance : StripeEntity<ChargePaymentMethodDetailsCustomerBalance>
    {
    }
}
