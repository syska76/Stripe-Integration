// File generated from our OpenAPI spec
namespace Stripe
{
    public class PaymentMethodBlik : StripeEntity<PaymentMethodBlik>
    {
    }
}
