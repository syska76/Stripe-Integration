// File generated from our OpenAPI spec
namespace Stripe
{
    public class PaymentMethodCustomerBalance : StripeEntity<PaymentMethodCustomerBalance>
    {
    }
}
