// File generated from our OpenAPI spec
namespace Stripe
{
    public class PaymentMethodCardWalletAmexExpressCheckout : StripeEntity<PaymentMethodCardWalletAmexExpressCheckout>
    {
    }
}
