// File generated from our OpenAPI spec
namespace Stripe
{
    public static class AccountType
    {
        public const string Custom = "custom";

        public const string Express = "express";

        public const string Standard = "standard";
    }
}