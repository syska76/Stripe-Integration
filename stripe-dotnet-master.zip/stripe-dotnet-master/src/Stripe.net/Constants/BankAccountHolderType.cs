namespace Stripe
{
    public static class BankAccountHolderType
    {
        public const string Individual = "individual";

        public const string Company = "company";
    }
}
