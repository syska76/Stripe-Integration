// File generated from our OpenAPI spec
namespace Stripe
{
    internal class ApiVersion
    {
        public const string Current = "2022-08-01";
    }
}