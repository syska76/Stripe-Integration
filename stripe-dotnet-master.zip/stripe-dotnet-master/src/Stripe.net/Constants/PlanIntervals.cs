// File generated from our OpenAPI spec
namespace Stripe
{
    public static class PlanIntervals
    {
        public const string Day = "day";

        public const string Month = "month";

        public const string Week = "week";

        public const string Year = "year";
    }
}