namespace Stripe
{
    public static class SourceUsage
    {
        public const string Reusable = "reusable";

        public const string SingleUse = "single_use";
    }
}
